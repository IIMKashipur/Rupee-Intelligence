# =============================================================================
# 05_classification.R  -  Sessions 12-14: Rupee Stress Monitor
# Target: High_Pressure = month's depreciation above the TRAIN 75th percentile
# Two set-ups, reported separately and labelled honestly:
#   Early warning : uses only LAST month's data  (a true forecast)
#   Nowcast       : uses the SAME month's drivers (explains, cannot forecast)
# Methods: logistic regression, LDA, decision tree, SVM + confusion matrices
# =============================================================================
source("R/00_config.R")
md  <- readr::read_csv(file.path(DIR_PROCESSED, "model_data.csv"), show_col_types = FALSE)
out <- function(f) file.path(DIR_OUTPUT, f)
sink(out("05_classification.txt"), split = TRUE)
set.seed(2026)  # only fixes SVM's internal cross-validation; no data is generated

md <- md |> mutate(High_Pressure = factor(High_Pressure, levels = c("Normal", "High"))) |>
  drop_na(L1_FPI, L1_INR_ret, L1_INR_vol, L1_Brent_ret, L1_USD_ret, L1_VIX_chg)
train <- md |> filter(date <= TRAIN_END)
test  <- md |> filter(date >= TEST_START)
cat("Class balance (train):\n"); print(table(train$High_Pressure))
cutoff <- mean(train$High_Pressure == "High")   # prior share as decision cutoff

setups <- list(
  EarlyWarning = High_Pressure ~ L1_INR_ret + L1_INR_vol + L1_Brent_ret +
                                 L1_USD_ret + L1_FPI + L1_VIX_chg + L1_Reserves_chg,
  Nowcast      = High_Pressure ~ Brent_ret + USD_ret + FPI + VIX_chg +
                                 d_Rate_diff + d_Trade_Bal + Infl_diff
)

evaluate <- function(prob, truth, label) {
  pred <- factor(ifelse(prob > cutoff, "High", "Normal"), levels = c("Normal", "High"))
  cm   <- caret::confusionMatrix(pred, truth, positive = "High")
  auc  <- tryCatch(as.numeric(pROC::auc(pROC::roc(truth, prob, quiet = TRUE))),
                   error = function(e) NA)
  cat("\n---", label, "---\n"); print(cm$table)
  tibble::tibble(model = label, accuracy = cm$overall["Accuracy"],
                 sensitivity = cm$byClass["Sensitivity"],
                 specificity = cm$byClass["Specificity"],
                 precision   = cm$byClass["Pos Pred Value"],
                 balanced_acc = cm$byClass["Balanced Accuracy"], AUC = auc)
}

results <- list(); fitted_models <- list()
for (s in names(setups)) {
  fo <- setups[[s]]
  cat("\n#################", s, "#################\n")

  logit <- glm(fo, data = train, family = binomial)
  print(summary(logit))
  cat("Odds ratios:\n"); print(round(exp(coef(logit)), 3))
  results[[length(results) + 1]] <- evaluate(
    predict(logit, test, type = "response"), test$High_Pressure, paste(s, "- Logistic"))

  lda_m <- MASS::lda(fo, data = train)
  results[[length(results) + 1]] <- evaluate(
    predict(lda_m, test)$posterior[, "High"], test$High_Pressure, paste(s, "- LDA"))

  tree <- rpart::rpart(fo, data = train, method = "class",
                       control = rpart::rpart.control(cp = 0.01, minbucket = 8))
  best_cp <- tree$cptable[which.min(tree$cptable[, "xerror"]), "CP"]
  tree <- rpart::prune(tree, cp = best_cp)
  png(out(paste0("fig_tree_", s, ".png")), width = 1100, height = 800, res = 130)
  rpart.plot::rpart.plot(tree, main = paste("Decision tree -", s), extra = 104)
  dev.off()
  results[[length(results) + 1]] <- evaluate(
    predict(tree, test, type = "prob")[, "High"], test$High_Pressure, paste(s, "- Tree"))

  svm_m <- e1071::svm(fo, data = train, kernel = "radial", probability = TRUE,
                      scale = TRUE)
  sp <- attr(predict(svm_m, test, probability = TRUE), "probabilities")[, "High"]
  results[[length(results) + 1]] <- evaluate(sp, test$High_Pressure, paste(s, "- SVM"))

  fitted_models[[s]] <- list(logit = logit, lda = lda_m, tree = tree, svm = svm_m)
}

res <- bind_rows(results)
cat("\nTest-period performance (2023 onward):\n"); print(res, width = Inf)
readr::write_csv(res, out("classification_results.csv"))

# Month-by-month stress probabilities for the dashboard (nowcast logistic)
all_prob <- md |> mutate(
  p_high_early = predict(fitted_models$EarlyWarning$logit, md, type = "response"),
  p_high_now   = predict(fitted_models$Nowcast$logit,      md, type = "response"),
  set = ifelse(date <= TRAIN_END, "Train", "Test")) |>
  select(date, USDINR, INR_ret, High_Pressure, p_high_early, p_high_now, set)
readr::write_csv(all_prob, out("stress_probabilities.csv"))
saveRDS(list(models = fitted_models, results = res, cutoff = cutoff),
        out("classification_models.rds"))
sink()
